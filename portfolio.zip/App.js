import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { Ionicons } from '@expo/vector-icons';
import Toast from 'react-native-toast-message';

// Import Screens
import HomeScreen from './screens/HomeScreen';
import AboutScreen from './screens/AboutScreen';
import ProjectsScreen from './screens/ProjectsScreen';
import ContactScreen from './screens/ContactScreen';
import ProjectDetailsScreen from './screens/ProjectDetailsScreen';
import DetailsScreen from './screens/DetailsScreen';
import SpinningIcon from './screens/SpinningIcon'; // Import SpinningIcon

// Stack Navigator for Projects
const ProjectsStack = createStackNavigator();
function ProjectsStackNavigator() {
  return (
    <ProjectsStack.Navigator>
      <ProjectsStack.Screen name="ProjectList" component={ProjectsScreen} options={{ headerShown: false }}/>
      <ProjectsStack.Screen name="ProjectDetails" component={ProjectDetailsScreen} options={{ headerShown: false }}/>
    </ProjectsStack.Navigator>
  );
}

// Bottom Tab Navigator
const Tab = createBottomTabNavigator();
function BottomTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === 'HomeTab') {
            iconName = 'home';
          } else if (route.name === 'AboutTab') {
            iconName = 'information-circle';
          } else if (route.name === 'ProjectsTab') {
            iconName = 'briefcase';
          } else if (route.name === 'ContactTab') {
            iconName = 'call';
          }
          // Use SpinningIcon component for 'call' icon
          return iconName === 'call' ? (
            <SpinningIcon name={iconName} size={size} color={color} />
          ) : (
            <Ionicons name={iconName} size={size} color={color} />
          );
        },
        tabBarActiveTintColor: '#007bff',
        tabBarInactiveTintColor: 'gray',
      })}
    >
      <Tab.Screen name="HomeTab" component={HomeScreen} options={{ headerShown: false }}/>
      <Tab.Screen name="AboutTab" component={AboutScreen} options={{ headerShown: false }}/>
      <Tab.Screen name="ProjectsTab" component={ProjectsStackNavigator} options={{ headerShown: false }}/>
      <Tab.Screen
        name="ContactTab"
        component={ContactScreen}
        options={{ headerShown: false }} 
      />

    </Tab.Navigator>
  );
}

// Drawer Navigator
const Drawer = createDrawerNavigator();
function DrawerNavigator() {
  return (
    <Drawer.Navigator initialRouteName="Main">
      <Drawer.Screen name="Bhavesh Portfolio" component={BottomTabNavigator} />
      <Drawer.Screen name="Details" component={DetailsScreen} />
    </Drawer.Navigator>
  );
}

// Root Stack Navigator
const RootStack = createStackNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Toast ref={(ref) => Toast.setRef(ref)} />

      <RootStack.Navigator screenOptions={{ headerShown: false }}>
        <RootStack.Screen name="DrawerNavigator" component={DrawerNavigator} />
      </RootStack.Navigator>
    </NavigationContainer>
  );
}
