import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  containerContact: {
    flex: 1,
    backgroundColor: '#282c34',
    padding: 20,
    justifyContent: 'center',

  },
  titleContact: {
    fontSize: 24,
    color: '#fff',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: '#fff',
    borderBottomWidth: 1,
    color: '#000',
    marginBottom: 15,
    paddingHorizontal: 10,
    backgroundColor:'white'
  },
  messageInput: {
    height: 100,
    textAlignVertical: 'top',
  },
  button: {
    backgroundColor: '#61dafb',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginVertical: 10,
  },
  buttonText: {
    color: '#282c34',
    fontSize: 16,
  },
  socialContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 30,
    // backgroundColor:'white'
    color:'white'

  },
  icon: {
    marginHorizontal: 15, // Space between icons
    color:'white',

  },
  link: {
    color: '#007bff',
    fontSize: 16,
    marginVertical: 5,
  },
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f9f9f9',
    backgroundColor: '#282c34',

  },
  sectionWrapper: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 8,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  titleSpan: {
    color: '#007bff',
  },
  subtitle: {
    fontSize: 16,
    color: '#333',
    marginVertical: 8,
  },
  description: {
    fontSize: 16,
    color: '#333',
  },
  subheading: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  experienceItem: {
    marginBottom: 16,
  },
  jobTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  company: {
    fontSize: 16,
    fontStyle: 'italic',
  },
  duration: {
    fontSize: 14,
    color: '#777',
  },
  location: {
    fontSize: 14,
    color: '#777',
  },
  experienceDescription: {
    fontSize: 16,
    color: '#333',
    marginVertical: 8,
  },
  skillsList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  skill: {
    backgroundColor: '#007bff',
    color: '#fff',
    padding: 8,
    margin: 4,
    borderRadius: 4,
  },
  educationItem: {
    marginBottom: 12,
  },
  eduInstitution: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  eduDetails: {
    fontSize: 14,
    color: '#777',
  },
  containerProject: {
    padding: 20,
    backgroundColor: '#282c34',

  },
  project: {
    marginBottom: 20,
    padding: 15,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3, // For Android shadow
  },
  title: {
    fontSize: 18,
    marginBottom: 10,
    fontWeight: 'bold',
  },
  description: {
    marginBottom: 10,
  },
  technologies: {
    fontStyle: 'italic',
    marginBottom: 10,
  },
  linkButton: {
    marginTop: 10,
  },
  link: {
    color: '#007BFF',
    textDecorationLine: 'none',
  },
  bold: {
    fontWeight: 'bold',
  },
  containerHome: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#282c34',
    padding: 20,
  },
  titleHome: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#61dafb',
    textAlign: 'center',
  },
  subtitleHome: {
    fontSize: 18,
    color: '#ffffff',
    marginTop: 10,
    textAlign: 'center',
  },
  descriptionHome: {
    fontSize: 16,
    color: '#ffffff',
    textAlign: 'center',
    marginTop: 20,
    marginHorizontal: 20,
  },
  buttonHome: {
    marginTop: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#61dafb',
    borderRadius: 30,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#282c34',
  },
  overlay: {
    position: 'absolute',
    bottom: 20,
    width: '100%',
    height: 60,
    backgroundColor: '#61dafb',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 30,
  },
  overlayText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#282c34',
  },
});

export default styles;
