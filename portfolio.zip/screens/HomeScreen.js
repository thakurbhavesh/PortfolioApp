import React, { useEffect, useRef } from 'react';
import { View, Text, Animated, StyleSheet, TouchableOpacity } from 'react-native';
import styles from '../styles/styles';


export default function HomeScreen({ navigation }) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const translateYAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }).start(),
      Animated.timing(translateYAnim, {
        toValue: 0,
        duration: 1000,
        useNativeDriver: true,
      }).start(),
    ]);
  }, [fadeAnim, translateYAnim]);

  const handleExplorePress = () => {
    // Navigate to Projects or About Screen
    navigation.navigate('ProjectsTab'); // Adjust to the correct screen name
  };

  return (
    <Animated.View style={[styles.containerHome, { opacity: fadeAnim, transform: [{ translateY: translateYAnim }] }]}>
      <Text style={styles.titleHome}>Welcome to My Portfolio</Text>
      <Text style={styles.subtitleHome}>Bhavesh Singh - Web & Mobile Developer</Text>
      <Text style={styles.descriptionHome}>
        I am a dedicated professional with 2 years of experience in web and mobile app development. Currently working at Aabhyasa Technology, I specialize in designing test automation frameworks, writing code in various languages, and solving complex engineering problems. My skills range from PHP and JavaScript to React and mobile development.
      </Text>
      <TouchableOpacity style={styles.buttonHome} onPress={handleExplorePress}>
        <Text style={styles.buttonText}>Explore My Work</Text>
      </TouchableOpacity>
      
    </Animated.View>
  );
}


