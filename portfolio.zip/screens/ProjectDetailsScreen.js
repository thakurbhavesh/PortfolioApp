import { View, Text } from 'react-native'
import React from 'react'

export default function ProjectDetailsScreen() {
  return (
    <View>
      <Text>ProjectDetailsScreen</Text>
    </View>
  )
}