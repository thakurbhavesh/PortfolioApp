import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const projectDetails = {
  title: 'Bhavesh’s Portfolio',
  description: 'This portfolio app showcases various projects and skills in web and mobile development. It includes interactive screens with animations, detailed project descriptions, and contact options.',
  technologies: ['React Native', 'Expo', 'React Navigation', 'React Native Reanimated', 'React Native Toast Message'],
  languages: ['JavaScript', 'TypeScript'],
  packages: [
    { name: 'react-navigation', description: 'Routing and navigation for Expo and React Native apps.' },
    { name: 'react-native-reanimated', description: 'Library for animations and transitions.' },
    { name: 'react-native-toast-message', description: 'Toast messages for user feedback.' },
    { name: 'expo', description: 'Framework for building React Native apps with ease.' },
    { name: 'react-native-vector-icons', description: 'Icons for React Native apps.' },
  ],
  screens: [
    { name: 'HomeScreen', description: 'The main screen of the app with an introduction and navigation options.' },
    { name: 'ProjectsScreen', description: 'Displays a list of projects with animations and links.' },
    { name: 'DetailsScreen', description: 'Shows detailed information about a specific project.' },
    { name: 'ContactScreen', description: 'Form to contact the developer and social media links.' },
    { name: 'AboutScreen', description: 'Shows detailed information about the developer, including experience, skills, and education.' },
  ],
  links: [
    { label: 'GitHub Repository', url: 'https://github.com/thakurbhavesh' },
    { label: 'Live Demo Website', url: 'https://thakurbhavesh.netlify.app/' },
  ],
};

const DetailsScreen = () => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.detailsContainer}>
        <Text style={styles.title}>{projectDetails.title}</Text>
        <Text style={styles.description}>{projectDetails.description}</Text>

        <Text style={styles.subheading}>Technologies Used:</Text>
        <View style={styles.listContainer}>
          {projectDetails.technologies.map((tech, index) => (
            <Text key={index} style={styles.listItem}>
              <Ionicons name="hardware-chip" size={16} color="#007bff" /> {tech}
            </Text>
          ))}
        </View>

        <Text style={styles.subheading}>Languages Used:</Text>
        <View style={styles.listContainer}>
          {projectDetails.languages.map((lang, index) => (
            <Text key={index} style={styles.listItem}>
              <Ionicons name="code-slash" size={16} color="#007bff" /> {lang}
            </Text>
          ))}
        </View>

        <Text style={styles.subheading}>Packages:</Text>
        <View style={styles.listContainer}>
          {projectDetails.packages.map((pkg, index) => (
            <View key={index} style={styles.packageItem}>
              <Text style={styles.packageName}>{pkg.name}</Text>
              <Text style={styles.packageDescription}>{pkg.description}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.subheading}>Screens:</Text>
        <View style={styles.listContainer}>
          {projectDetails.screens.map((screen, index) => (
            <View key={index} style={styles.screenItem}>
              <Text style={styles.screenName}>{screen.name}</Text>
              <Text style={styles.screenDescription}>{screen.description}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.subheading}>Links:</Text>
        <View style={styles.linkContainer}>
          {projectDetails.links.map((link, index) => (
            <TouchableOpacity key={index} onPress={() => Linking.openURL(link.url)} style={styles.linkItem}>
              <Text style={styles.linkText}>{link.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#282c34',
  },
  detailsContainer: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  description: {
    fontSize: 16,
    color: '#555',
    marginBottom: 20,
  },
  subheading: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 10,
    color: '#fff',
    backgroundColor:'#282c34',
    padding:10
  },
  listContainer: {
    marginBottom: 20,
  },
  listItem: {
    fontSize: 16,
    color: '#555',
    marginBottom: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  packageItem: {
    marginBottom: 10,
  },
  packageName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#007bff',
  },
  packageDescription: {
    fontSize: 16,
    color: '#333',
  },
  screenItem: {
    marginBottom: 10,
  },
  screenName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#007bff',
  },
  screenDescription: {
    fontSize: 16,
    color: '#333',
  },
  linkContainer: {
    marginTop: 10,
  },
  linkItem: {
    marginBottom: 5,
  },
  linkText: {
    fontSize: 16,
    color: '#007bff',
    textDecorationLine: 'underline',
  },
});

export default DetailsScreen;
