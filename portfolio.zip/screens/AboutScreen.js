import React from 'react';
import { View, Text, ScrollView, Animated } from 'react-native';
import styles from '../styles/styles';

const AboutScreen = () => {
  const fadeAnim = new Animated.Value(0); // Initial value for opacity
  const slideAnim = new Animated.Value(50); // Initial value for translateY

  React.useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }).start(),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }).start(),
    ]);
  }, [fadeAnim, slideAnim]);

  const animatedStyle = {
    opacity: fadeAnim,
    transform: [{ translateY: slideAnim }],
  };

  return (
    <ScrollView style={styles.container}>
      <Animated.View style={[styles.sectionWrapper, { opacity: fadeAnim }]}>
        <Text style={styles.title}>About <Text style={styles.titleSpan}>Me</Text></Text>
        <Text style={styles.subtitle}>Web Developer & Mobile App Developer | Ayodhya, India</Text>
        <Text style={styles.description}>
          I am a focused professional with 2 years of experience in the computer industry, currently working at Aabhyasa Technology. My expertise lies in designing and implementing test automation frameworks, writing code across various languages, and developing innovative solutions to complex engineering problems. I am adept at both technical and communication skills, bringing a creative approach to problem-solving and feature development.
        </Text>
      </Animated.View>

      <Animated.View style={[styles.sectionWrapper, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
        <Text style={styles.subheading}>Experience</Text>
        <View style={styles.experienceItem}>
          <Text style={styles.jobTitle}>PHP Developer</Text>
          <Text style={styles.company}>Aabhyasa Technologies Pvt Ltd</Text>
          <Text style={styles.duration}>Jun 2022 - Present · 2 yrs 3 mos</Text>
          <Text style={styles.location}>Varanasi, Uttar Pradesh, India</Text>
          <Text style={styles.experienceDescription}>
            Working as a PHP Developer, I focus on implementing Stripe payments, HTML5, and other technologies. My role involves designing and developing robust PHP applications, ensuring high performance and scalability.
          </Text>
          <View style={styles.skillsList}>
            <Text style={styles.skill}>PHP</Text>
            <Text style={styles.skill}>HTML5</Text>
            <Text style={styles.skill}>Stripe</Text>
          </View>
        </View>
        {/* Add more experience items as needed */}
      </Animated.View>

      <Animated.View style={[styles.sectionWrapper, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
        <Text style={styles.subheading}>What Skills I Have</Text>
        <View style={styles.skillsList}>
          <Text style={styles.skill}>HTML</Text>
          <Text style={styles.skill}>CSS</Text>
          <Text style={styles.skill}>JS</Text>
          <Text style={styles.skill}>Bootstrap</Text>
          <Text style={styles.skill}>PHP</Text>
          <Text style={styles.skill}>React</Text>
          <Text style={styles.skill}>Stripe</Text>
          <Text style={styles.skill}>Paypal</Text>
        </View>
      </Animated.View>

      <Animated.View style={[styles.sectionWrapper, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
        <Text style={styles.subheading}>Education</Text>
        <View style={styles.educationItem}>
          <Text style={styles.eduInstitution}>M.P.L.L. Adarsh Inter College Ayodhya</Text>
          <Text style={styles.eduDetails}>High School, Commerce · (2015 - 2016)</Text>
        </View>
        <View style={styles.educationItem}>
          <Text style={styles.eduInstitution}>M.P.L.L. Adarsh Inter College</Text>
          <Text style={styles.eduDetails}>Intermediate, Mathematics · (2017 - 2018)</Text>
        </View>
        <View style={styles.educationItem}>
          <Text style={styles.eduInstitution}>C.S.J.M. Government Polytechnic Ambedkar</Text>
          <Text style={styles.eduDetails}>Diploma in Computer Science · (2018 - 2021)</Text>
        </View>
      </Animated.View>

      <Animated.View style={[styles.sectionWrapper, animatedStyle]}>
        <Text style={styles.subheading}>Training</Text>
        <View style={styles.experienceItem}>
          <Text style={styles.jobTitle}>Apprentice</Text>
          <Text style={styles.company}>Techpile Technology Pvt. Ltd.</Text>
          <Text style={styles.duration}>Sep 2021 - Mar 2022 · 7 mos</Text>
          <Text style={styles.location}>Lucknow, Uttar Pradesh, India</Text>
          <Text style={styles.experienceDescription}>
            During my 7-month apprenticeship, I worked on PHP development, mastering frameworks, database management, and API integrations. I contributed to diverse projects and adhered to industry best practices.
          </Text>
          <View style={styles.skillsList}>
            <Text style={styles.skill}>PHP</Text>
            <Text style={styles.skill}>Database Management</Text>
            <Text style={styles.skill}>API Integrations</Text>
          </View>
        </View>
        <View style={styles.experienceItem}>
          <Text style={styles.jobTitle}>Summer Intern</Text>
          <Text style={styles.company}>Softpro India Computer Technologies (P) Ltd.</Text>
          <Text style={styles.duration}>Jun 2020 - Oct 2020 · 5 mos</Text>
          <Text style={styles.location}>Lucknow, Uttar Pradesh, India</Text>
          <Text style={styles.experienceDescription}>
            As a Summer Intern, I gained experience with Django and Bootstrap, contributing to various projects and learning best practices in web development.
          </Text>
          <View style={styles.skillsList}>
            <Text style={styles.skill}>Django</Text>
            <Text style={styles.skill}>Bootstrap</Text>
          </View>
        </View>
      </Animated.View>
    </ScrollView>
  );
};

export default AboutScreen;
