import React from 'react';
import { View, Text, StyleSheet, Animated, ScrollView, TouchableOpacity, Linking } from 'react-native';
import Toast from 'react-native-toast-message';
import styles from '../styles/styles';

// Sample data
const projects = [
  {
    title: 'My Portfolio Website',
    description: 'A personal website to showcase my projects and skills.',
    technologies: ['React', 'CSS Modules'],
    link: 'https://myportfolio.com'
  },
  {
    title: 'Conference Website',
    description: 'Providing high-quality webinars to healthcare professionals.',
    technologies: ['Php', 'Bootstrap'],
    link: 'https://conferencestable.com/'
  },
  {
    title: 'Text to Html',
    description: 'Converts plain text into well-structured HTML.',
    technologies: ['Html','Bootstrap','Css'],
    link: 'https://complianceelite.com/text_to_html.php'
  },
  {
    title: 'Excel Split Data',
    description: 'Split Data',
    technologies: ['Html','Bootstrap','Css',['Php']],
    link: 'https://complianceelite.com/text_to_html.php'
  }
];

const ProjectsScreen = () => {
  // Animation values
  const fadeAnim = React.useRef(new Animated.Value(0)).current;

  // Animation effect
  React.useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, [fadeAnim]);

  const handlePress = (link, title) => {
    Toast.show({
      type: 'success',
      position: 'bottom',
      text1: 'Opening Project',
      text2: `You are about to open ${title}`,
      visibilityTime: 3000,
      autoHide: true,
    });

    Linking.openURL(link).catch((err) => console.error('Failed to open URL:', err));
  };

  return (
    <ScrollView contentContainerStyle={styles.containerProject}>
      {projects.map((project, index) => (
        <Animated.View
          key={index}
          style={[styles.project, { opacity: fadeAnim, transform: [{ scale: fadeAnim.interpolate({ inputRange: [0, 1], outputRange: [0.9, 1] }) }] }]}>
          <Text style={styles.title}>{project.title}</Text>
          <Text style={styles.description}>{project.description}</Text>
          <Text style={styles.technologies}>
            <Text style={styles.bold}>Technologies:</Text> {project.technologies.join(', ')}
          </Text>
          <TouchableOpacity onPress={() => handlePress(project.link, project.title)} style={styles.linkButton}>
            <Text style={styles.link}>View Project</Text>
          </TouchableOpacity>
        </Animated.View>
      ))}
      <Toast ref={(ref) => Toast.setRef(ref)} />
    </ScrollView>
  );
};

export default ProjectsScreen;
