import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Linking, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import styles from '../styles/styles';
import Toast from 'react-native-toast-message';

export default function ContactScreen() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = () => {
    Toast.show({
      type: 'success',
      position: 'bottom',
      text1: 'Form Submitted',
      text2: `Name: ${name}\nEmail: ${email}\nMessage: ${message}`,
      visibilityTime: 2000, // Toast duration
      autoHide: true,
    });
    setName('');
    setEmail('');
    setMessage('');
  };

  return (
    <View style={styles.containerContact}>
      <Text style={styles.titleContact}>Contact Me</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Name"
        placeholderTextColor="#aaa"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Email"
        placeholderTextColor="#aaa"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />
      <TextInput
        style={[styles.input, styles.messageInput]}
        placeholder="Message"
        placeholderTextColor="#aaa"
        value={message}
        onChangeText={setMessage}
        multiline
        numberOfLines={4}
      />
      
      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Submit</Text>
      </TouchableOpacity>
      
      <View style={styles.socialContainer}>
        <TouchableOpacity onPress={() => Linking.openURL('https://www.linkedin.com/in/bhavesh-singh-04a74a1a5/')}>
          <Ionicons name="logo-linkedin" size={30} color="#0077B5" style={styles.icon} />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => Linking.openURL('https://github.com/thakurbhavesh')}>
          <Ionicons name="logo-github" size={30} color="#333" style={styles.icon} />
        </TouchableOpacity>
        {/* <TouchableOpacity onPress={() => Linking.openURL('https://youtube.com/bhavesh')}>
          <Ionicons name="logo-youtube" size={30} color="#FF0000" style={styles.icon} />
        </TouchableOpacity> */}
      </View>

      <Toast ref={(ref) => Toast.setRef(ref)} />
    </View>
  );
}

